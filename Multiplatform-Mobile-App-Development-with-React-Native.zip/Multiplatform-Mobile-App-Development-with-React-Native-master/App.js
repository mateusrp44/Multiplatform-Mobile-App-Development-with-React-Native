import React from 'react';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';

import { ConfigureStore } from './redux/configureStore';
import { Loading } from './components/loadingcomponent';
import Main from './components/maincomponent';

const { persistor, store } = ConfigureStore({});

export default class App extends React.Component {
  render() {
    return (
      <Provider store={ store }>
        <PersistGate loading={<Loading />} persistor={ persistor }>
          <Main />
        </PersistGate>
      </Provider>
    );
  }
}

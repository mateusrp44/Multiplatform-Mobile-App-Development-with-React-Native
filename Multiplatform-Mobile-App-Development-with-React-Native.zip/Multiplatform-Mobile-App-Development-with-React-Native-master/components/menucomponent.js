import React, { Component } from 'react';
import { FlatList, View, Text, ScrollView } from 'react-native';
import { Tile } from 'react-native-elements';
import { connect } from 'react-redux';
import * as Animatable from 'react-native-animatable';

import { Loading } from './loadingcomponent';
import { baseUrl } from '../shared/baseUrl';

const mapStateToProps = state => {
    return {
        dishes: state.dishes
    }
}

MenuOfDishes = (props) => {
    if (props.isLoading) {
        return (
            <ScrollView>
                <Loading />
            </ScrollView>
        );
    }
    else if (props.errMess) {
        return (
            <ScrollView>
                <Text>{props.errMess}</Text>
            </ScrollView>
        );
    }
    else {
        const dishes = props.dishes;
        if (dishes != null) {
            return (
                <ScrollView>
                    <FlatList
                        data={dishes}
                        renderItem={renderMenuItem}
                        keyExtractor={item => item.id.toString()} />
                </ScrollView>
            );
        }
        else return (<View></View>)
    }
}

class Menu extends Component {
    static navigationOptions = {
        title: 'Menu'
    };

    render() {
        renderMenuItem = ({ item, index }) => {
            const { navigate } = this.props.navigation;
            return (
                <Animatable.View animation="fadeInRightBig" duration={2000}>
                    <Tile
                        key={index}
                        title={item.name}
                        caption={item.description}
                        featured
                        onPress={() => navigate('DishDetail', { dishId: item.id })}
                        imageSrc={{ uri: baseUrl + item.image }} />
                </Animatable.View>
            );
        };

        return (
            <ScrollView>
                <MenuOfDishes
                    dishes={this.props.dishes.dishes}
                    isLoading={this.props.dishes.isLoading}
                    errMess={this.props.dishes.errMess} />
            </ScrollView>
        );
    }
}

export default connect(mapStateToProps)(Menu);
